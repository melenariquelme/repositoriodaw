
public class EstuvoAqui {

	public static void main(String[] args) {

		System.out.println("JM ya estuvo aquí \n");
		
		System.out.println("Jose Manuel ha estado hoy aqui \n");

		System.out.println("Ismael ha estado hoy aqui \n");

		System.out.println("JM ya estuvo aquí dos veces\n");

		System.out.println("JM ya estuvo aquí tresveces\n");

	}

}
